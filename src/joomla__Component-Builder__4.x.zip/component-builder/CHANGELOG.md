# v4.1.2

- Fix the template and layout linker for packages.
- Add native module builder for Joomla 4/5
- Refactor dynamic get methods into dedicated classes
- Move Joomla DB handling into compiler injector flow
- Fix auto-check(in) method for Joomla 4/5 compatibility
- Migrates view HTML classes to use getModel() directly instead of the deprecated magic get() calls to model methods.
- Refactores event handling (contentPrepare, titlePrepare, contentBeforeDisplay, contentAfterDisplay) to use Joomla 5's native event dispatcher via the model's new getDispatcher() method.
- Updates table classes to properly support NULL values, both in the store() method and in table variable definitions. #1245
- Extractes the setAutoCheckIn() and setCheckInCall() logic into a dedicated CheckInNow class for cleaner design.
- Replace all direct $app->input property calls with the recommended $app->getInput() method across the entire codebase.
- Add Joomla 6 build option
- Fix Custom Rule Validation Bug
- Unpublish Joomla 6 Backward Compatibility Plugin
- Refactors the Compiler Model by dropping deprecated calls and adopting Joomla 5+ conventions
- Refactors Compiler Controller to remove deprecated usage and follow Joomla 5+ best practices
- Adds check to ensure expert mode subforms in the Demo Component remain set and unchanged when user lacks edit permissions
- Improves validation handling of Fields by ensuring field validation rules are properly registered
- Replace StringHelper with the correct Super Power key so it loads in the Compiler Controller
- Add functionality to add component changelog into the package if configured.
- Refactor PHP classes for building HTML view files in admin and site views to align with Joomla 5+ standards.
- Fix issues in the site view HtmlView caused by the refactor, including missing class calls and outdated function references.
- Fix issue where the DatabaseSchemaCheckAll pulled all Component Builder tables into DB on install. #1253
- Fix issue in the Dynamic Get when the value key is 0 it wouldn't add the 'WHERE' statement to the generated code. #1254
- Change radio buttons with a empty option to save Datatype CHAR instead of TINYINT as other radio buttons. #1252
- Remove setDocumentTitle method from the admin view since it is not being used by Joomla. #1255
- Refactor compiler Move file update to classes.
- Refactor compiler Move plugin and module fields and rules files mover to classes.
- Fix issue where custom powers was not added to PowerloaderHelper. #1256
- Fix normalization issue when compiling on Windows systems. #1219
- Fix installer issue on Joomla 6 where components containing multiple plugins failed during installation.
- Completely refactors the Compiler Dashboard to align with Joomla 5+ architecture and Bootstrap 5 standards.
- Add a default VARCHAR(36) length to easily create fields intended to store GUID values.
- Update the file uploader in the Demo Component for more dynamic file display and naming.
- Update the SQL file dump generator to handle large SQL dumps in batches, ensuring safe and reliable database imports.
- Update example hints in the field expert mode options.

# v4.1.1

- Move all banners to GitHub.
- Adds library phpspreadsheet to JCB.
- Add import item example to demo component.
- Updates the Superpower class with the GetRemote class in the plugin.
- Ensures the super power autoloader triggers the correct repositories.
- Adds the Import Function to the Demo Component.
- Resolves the Database Updating issue in the compiler. #1212,#1209
- Adds the Component Commands Plugin to the  CLI for Import of spreadsheet data-sets.
- Add all needed Powers to the release package, to speed-up the build of the demo component.
- Refactored initialization flow to accommodate future scalability and integration with all designated areas.
- Refactor the Creator Builders class.
- Adds new JCB package engine.
- Fix issue with loading the Component Builder Wiki.
- Adds advanced version update notice to the Component Builder Dashboard.
- Completely refactors the class that builds the Component Dashboard. #1134
- Adds Initialize, Reset, and Push functionality to the Repository entities.
- Completely refactors the SQL teaks and SQL dump classes.
- Changes J4 fields to allow NULL.
- Fix a bug in Dynamic Get JavaScript that causes table columns to not load.
- Refactor the FieldString and FieldXML classes.
- Adds option to export Language Translations.

# v4.1.0

- Add [AllowDynamicProperties] in the base view class for J5
- Move the _prepareDocument  above the display call in the base view class
- Remove all backward compatibility issues, so JCB will not need the [Backward Compatibility] plugin to run.
- Added new import powers for custom import of spreadsheets.
- Move the setDocument and _prepareDocument above the display in the site view and custom admin view.
- Update the trashhelper layout to work in Joomla 5.
- Add AllowDynamicProperties (Joomla 4+5) to view class to allow Custom Dynamic Get methods to work without issues.
- Fix Save failed issue in dynamicGet. #1148
- Move all [TEXT, EDITOR, TEXTAREA] fields from [NOT NULL] to [NULL]
- Add the DateHelper class and improve the date methods.
- Add simple SessionHelper class.
- Add first classes for the new import engine.
- Improve the [VDM Registry] to be Joomla Registry Compatible
- Move all registries to the [VDM Registry] class
- Fix Checked Out to be null and not 0. (#1194)
- Fix created_by, modified_by, checked_out fields in the compiler of the SQL. (#1194)
- Update all core date fields in table class. (#1188)
- Update created_by, modified_by, checked_out fields in table class.
- Implementation of the decentralized Super-Power CORE repository network. (#1190)
- Fix the noticeboard to display Llewellyn's Joomla Social feed
- Started compiling JCB4 on Joomla 5 with PHP 8.2
- Add init_defaults option for dynamic form selection setup (to int new items with default values dynamically)
- Update all JCB 4 tables to utf8mb4_unicode_ci collation if misaligned
- Move all internal ID linking to GUID inside of JCB 4
- Updated the admin-tab-fields in add-fields view. #1205
- Remove Custom Import Tab from admin view
- Improved the customcode and placeholder search features

# v4.0.3

- Add [push] option to powers area.
- Fix [Save as Copy] error in library. #1162
- Fix error when no components exist. #1164
- Fix search page error caused by File class.
- Fix usergrouplist compiler triggers. #1100
- Add power field type integration [init, reset, push].
- Fix default database fields to allow NULL. #1169
- Fix power list field to enable search. #1167
- Expand the Demo component in JCB v4 to include more advanced features.
- Fix missing working path in zip process.
- Fix dynamic get issue in demo site view.
- Fix demo site view to display files.
- Fix field type init message.
- Ensure type-agnostic comparisons by casting to CHAR in joins for dynamic get.
- Fix dynamic download for site area with correct namespace.
- Fix missing edit button on fields in related views.
- Fix dashboard display.
- Restore search option in [use] field of related views.
- Fix namespace issue that broke the linker.

# v4.0.2

- Fix site view form missing classes in J4+
- Fix permissions tab in items in J4+
- Fix site display controller checkEditId function in J4+
- Add class methods to the HtmlView classes in J4+
- Fix broken toolbar call in HtmlView in J4+
- Fix missing scripts and styles fields and methods in the site admin view model
- Update subform field layout across JCB for cleaner look
- Remove expansion feature
- Fix helper area
- Fix database mySql update in J4+
- Remove phpspreadsheet completely from Joomla 4+
- Add option to use powers in preflight event in the installer class
- Fix abstract schema class function check default index warring
- Fix dynamicGet so that the table values will load again. #1155
- Add more pure JS to the dynamic get area
- Add native plugin builder for Joomla 4 & 5
- Add basic API for admin views

# v4.0.1

- Fix auto build from SQL in Joomla 4.
- Fix permission issue for admin views.
- Add in JCB gitea push feature to help maintain JCB core features.
- Add extending options to interfaces.
- Change the extendsinterfaces field to allow null, #1139
- Update the Schema class to also update null mismatching if needed
- Add repositories for better integration with gitea
- Refactored the Data classes
- Add new Data classes
- Add new subform classes
- Fix registry class methods return type
- Update all list and custom fields to use the new layouts
- Add push options to Joomla Power
- Complete the Joomla Power Init and Reset features
- Fix Gitea Contents class functions
- Fix subform set methods
- Improved the Joomla Power Push path
- Fix the metadata, metadesc, metakey database issue
- Fix function mismatch call in the compiler power class.
- Fix init feature to only add missing powers
- Fix controller postSaveHook function, for correct model class in Joomla 4 and 5
- Fix app instances (mismatch) in the install script and schema class when installing from CLI
- Add option to use placeholders in Joomla Power namespaces.
- Fix subform layout of uikit in JCB

# v4.0.0

- Fix the plug-in installer script builder bug #1067
- Fix Event triggers for Joomla 4 and 5 builds.
- Add fix to the update script, so that upgrading JCB from Joomla 3 to 4 will not fail.
- Fix plugin field selection
- Fix plugin params tab layout
- Add issue templates
- Force autoloader to always load. 
- Fix repeatable layout #1076
- Add Factory class to the J5 Event class. #1093
- Fix customfilelist field to conform to the new namespacing conventions. #1094
- Add menus for languages, servers, get snippets to J4 #1095
- Fix [Set String Value] in placeholder table to store the value as a base64 string.
- Fix the search area layout.
- Fix the search area code line selection.
- Fix the input edit button for custom fields.
- Add the new layout to list fields (GUI UPDATE)
- Start fixing the field view in Joomla 4. #1096
- Add power path override option on component level.
- Fix the sql build feature. #1032
- Add the compiler menu back.
- Fix the CustomfolderlistField #1094
- Add view list and single name fix.
- Add component code name fix.
- Add reset list of powers.
- Add Joomla powers for namespace dynamic management.
- Add fallback option to ensure that all JCB tables and fields exist.
- Move the powers autoloader to its own file.
- Fix the media field size limitation. #1109
- Add dynamic datatype update to schema field check.
- Fix version_update column size.
- Improved the Schema Table update engine.
- Improved the Schema Table update engine (more).
- Fix autoloader timing, and loading.
- Implement the Joomla Powers in JCB code, to move away from JClasses.
- Remove the SQL update, to only use the Schema updates of table columns to avoid collusion.
- Fix the admin.css file loading on dashboard. #1112
- Fix dynamic get data-type default to 0. #1110
- Fix the missing model call. #1114
- Fix the wrong $date call. #1115
- Add the BaseDatabaseModel use statement to custom site view controller. #1119
- Fix the customfolderlist field. #1120

# v3.2.5

- Add [AllowDynamicProperties] in the base view class for J5
- Move the _prepareDocument  above the display call in the base view class
- Remove all backward compatibility issues, so JCB will not need the [Backward Compatibility] plugin to run.
- Added new import powers for custom import of spreadsheets.
- Move the setDocument and _prepareDocument above the display in the site view and custom admin view.
- Update the trashhelper layout to work in Joomla 5.
- Add AllowDynamicProperties (Joomla 4+5) to view class to allow Custom Dynamic Get methods to work without issues.
- Fix Save failed issue in dynamicGet. #1148
- Move all [TEXT, EDITOR, TEXTAREA] fields from [NOT NULL] to [NULL]
- Add the DateHelper class and improve the date methods.
- Add simple SessionHelper class.
- Add first classes for the new import engine.
- Improve the [VDM Registry] to be Joomla Registry Compatible
- Move all registries to the [VDM Registry] class
- Fix Checked Out to be null and not 0. (#1194)
- Fix created_by, modified_by, checked_out fields in the compiler of the SQL. (#1194)
- Update all core date fields in table class. (#1188)
- Update created_by, modified_by, checked_out fields in table class.
- Implementation of the decentralized Super-Power CORE repository network. (#1190)
- Fix the noticeboard to display Llewellyn's Joomla Social feed