# v4.0.0-alpha6

- Fix [Set String Value] in placeholder table to store the value as a base64 string.

# v4.0.0-alpha5

- Add Factory class to the J5 Event class. #1093
- Fix customfilelist field to conform to the new namespacing conventions. #1094
- Add menus for languages, servers, get snippets to J4 #1095

# v4.0.0-alpha4

- Fix plugin field selection
- Fix plugin params tab layout
- Add issue templates
- Force autoloader to always load. 
- Fix repeatable layout #1076

# v4.0.0-alpha3

- Add fix to the update script, so that upgrading JCB from Joomla 3 to 4 will not fail.

# v4.0.0-alpha2

- Fix the plug-in installer script builder bug #1067
- Fix Event triggers for Joomla 4 and 5 builds.

# v4.0.0-alpha1

- First alpha release of Component Builder towards Joomla 4 (very unstable...)

# v3.2.0-beta9

- Fix [Set String Value] in placeholder table to store the value as a base64 string.