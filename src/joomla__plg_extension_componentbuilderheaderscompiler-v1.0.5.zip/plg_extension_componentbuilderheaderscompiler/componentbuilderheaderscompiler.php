<?php
/**
 * @package    Joomla.Component.Builder
 *
 * @created    30th April, 2015
 * @author     Llewellyn van der Merwe <http://www.joomlacomponentbuilder.com>
 * @github     Joomla Component Builder <https://github.com/vdm-io/Joomla-Component-Builder>
 * @copyright  Copyright (C) 2015 Vast Development Method. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Application\CMSApplication;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Registry\Registry;

JLoader::register('ComponentbuilderHelper', JPATH_ADMINISTRATOR . '/components/com_componentbuilder/helpers/componentbuilder.php');

/**
 * Extension - Componentbuilder Headers Compiler plugin.
 *
 * @package   ComponentbuilderHeadersCompiler
 * @since     1.0.5
 */
class PlgExtensionComponentbuilderHeadersCompiler extends CMSPlugin
{
	/**
	 * Global switch to see if a file has custom headers.
	 *
	 * @var    boolean
	 * @since  1.0.0
	 */
	protected  $loadHeaders = false;

	/**
	 * The files active with headers
	 *
	 * @var    array
	 * @since  1.0.0
	 */
	protected  $activeFiles = array();

	/**
	 * The Targets
	 *
	 * @var    array
	 * @since  1.0.5
	 */
	protected $targets = array(
		'admin_view_headers' =>
			array(
				'add_admin_view_model'       => array(
					'field'   => 'admin_view_model',
					'context' => 'admin.view.model',
					'view'    => 'name_single'
				),
				'add_admin_view'       => array(
					'field'   => 'admin_view',
					'context' => 'admin.view',
					'view'    => 'name_single'
				),
				'add_admin_view_controller'  => array(
					'field'   => 'admin_view_controller',
					'context' => 'admin.view.controller',
					'view'    => 'name_single'
				),
				'add_admin_views_model'      => array(
					'field'   => 'admin_views_model',
					'context' => 'admin.views.model',
					'view'    => 'name_list'
				),
				'add_admin_views'      => array(
					'field'   => 'admin_views',
					'context' => 'admin.views',
					'view'    => 'name_list'
				),
				'add_admin_views_controller' => array(
					'field'   => 'admin_views_controller',
					'context' => 'admin.views.controller',
					'view'    => 'name_list'
				)
			),
		'site_view_headers' =>
			array(
				'add_site_view_model'       => array(
					'field'   => 'site_view_model',
					'context' => 'site.view.model',
					'view'    => 'code'
				),
				'add_site_view'       => array(
					'field'   => 'site_view',
					'context' => 'site.view',
					'view'    => 'code'
				),
				'add_site_view_controller'  => array(
					'field'   => 'site_view_controller',
					'context' => 'site.view.controller',
					'view'    => 'code'
				),
				'add_site_views_model'      => array(
					'field'   => 'site_views_model',
					'context' => 'site.views.model',
					'view'    => 'code'
				),
				'add_site_views'      => array(
					'field'   => 'site_views',
					'context' => 'site.views',
					'view'    => 'code'
				),
				'add_site_views_controller' => array(
					'field'   => 'site_views_controller',
					'context' => 'site.views.controller',
					'view'    => 'code'
				)
			),
		'custom_admin_view_headers' =>
			array(
				'add_custom_admin_view_model'       => array(
					'field'   => 'custom_admin_view_model',
					'context' => 'custom.admin.view.model',
					'view'    => 'code'
				),
				'add_custom_admin_view'       => array(
					'field'   => 'custom_admin_view',
					'context' => 'custom.admin.view',
					'view'    => 'code'
				),
				'add_custom_admin_view_controller'  => array(
					'field'   => 'custom_admin_view_controller',
					'context' => 'custom.admin.view.controller',
					'view'    => 'code'
				),
				'add_custom_admin_views_model'      => array(
					'field'   => 'custom_admin_views_model',
					'context' => 'custom.admin.views.model',
					'view'    => 'code'
				),
				'add_custom_admin_views'      => array(
					'field'   => 'custom_admin_views',
					'context' => 'custom.admin.views',
					'view'    => 'code'
				),
				'add_custom_admin_views_controller' => array(
					'field'   => 'custom_admin_views_controller',
					'context' => 'custom.admin.views.controller',
					'view'    => 'code'
				)
			),
		'joomla_component_headers' =>
			array(
				'add_admin_component'  => array(
					'field'   => 'admin_component',
					'context' => 'admin.component',
					'view'    => 'admin'
				),
				'add_site_component'  => array(
					'field'   => 'site_component',
					'context' => 'site.component',
					'view'    => 'site'
				),
				'add_admin_helper'  => array(
					'field'   => 'admin_helper',
					'context' => 'admin.helper',
					'view'    => 'admin'
				),
				'add_site_helper'  => array(
					'field'   => 'site_helper',
					'context' => 'site.helper',
					'view'    => 'site'
				)
			)
		);

	/**
	 * Event Triggered in the compiler [on Before Model View Data]
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function jcb_ce_onBeforeModelViewData(&$context, &$view,
		&$placeholders
	) {
		// add the privacy
		$view->params = (isset($view->params)
			&& ComponentbuilderHelper::checkJson($view->params)) ? json_decode(
			$view->params, true
		) : $view->params;
		if (ComponentbuilderHelper::checkArray($view->params)
			&& isset($view->params['admin_view_headers'])
			&& ComponentbuilderHelper::checkArray(
				$view->params['admin_view_headers']
			))
		{
			foreach ($this->targets['admin_view_headers'] as $target => $event)
			{
				if (isset($view->params['admin_view_headers'][$target])
					&& $view->params['admin_view_headers'][$target] == 1)
				{
					// activate the load of the privacy plugin
					$this->loadHeaders = true;
					// setup the view key name
					$view_name = ComponentbuilderHelper::safeString(
						$view->{$event['view']}
					);
					// load the headers
					$this->activeFiles[$view_name][$event['context']]
						= $view->params['admin_view_headers'][$event['field']];
				}
			}
		}
	}

	/**
	 * Event Triggered in the compiler [on Before Model Custom View Data]
	 *
	 * @return  void
	 *
	 * @since   1.2
	 */
	public function jcb_ce_onBeforeModelCustomViewData(&$context, &$view,
		&$id, &$table
	) {
		// add the privacy
		$view->params = (isset($view->params)
			&& ComponentbuilderHelper::checkJson($view->params)) ? json_decode(
			$view->params, true
		) : $view->params;
		// target site views
		if (ComponentbuilderHelper::checkArray($view->params)
			&& isset($view->params['site_view_headers'])
			&& ComponentbuilderHelper::checkArray(
				$view->params['site_view_headers']
			))
		{
			foreach ($this->targets['site_view_headers'] as $target => $event)
			{
				if (isset($view->params['site_view_headers'][$target])
					&& $view->params['site_view_headers'][$target] == 1)
				{
					// activate the load of the privacy plugin
					$this->loadHeaders = true;
					// setup the view key name
					$view_name = ComponentbuilderHelper::safeString(
						$view->{$event['view']}
					);
					// load the headers
					$this->activeFiles[$view_name][$event['context']]
						= $view->params['site_view_headers'][$event['field']];
				}
			}
		}
		// target custom admin views
		if (ComponentbuilderHelper::checkArray($view->params)
			&& isset($view->params['custom_admin_view_headers'])
			&& ComponentbuilderHelper::checkArray(
				$view->params['custom_admin_view_headers']
			))
		{
			foreach ($this->targets['custom_admin_view_headers'] as $target => $event)
			{
				if (isset($view->params['custom_admin_view_headers'][$target])
					&& $view->params['custom_admin_view_headers'][$target] == 1)
				{
					// activate the load of the privacy plugin
					$this->loadHeaders = true;
					// setup the view key name
					$view_name = ComponentbuilderHelper::safeString(
						$view->{$event['view']}
					);
					// load the headers
					$this->activeFiles[$view_name][$event['context']]
						= $view->params['custom_admin_view_headers'][$event['field']];
				}
			}
		}
	}

	/**
	 * Event Triggered in the compiler [on Before Model Component Data]
	 *
	 * @return  void
	 *
	 * @since   1.4
	 */
	public function jcb_ce_onBeforeModelComponentData(&$context, &$component)
	{
		// add the privacy
		$component->params = (isset($component->params)
			&& ComponentbuilderHelper::checkJson($component->params)) ? json_decode(
			$component->params, true
		) : $component->params;
		if (ComponentbuilderHelper::checkArray($component->params)
			&& isset($component->params['joomla_component_headers'])
			&& ComponentbuilderHelper::checkArray(
				$component->params['joomla_component_headers']
			))
		{
			foreach ($this->targets['joomla_component_headers'] as $target => $event)
			{
				if (isset($component->params['joomla_component_headers'][$target])
					&& $component->params['joomla_component_headers'][$target] == 1)
				{
					// activate the load of the privacy plugin
					$this->loadHeaders = true;
					// load the headers
					$this->activeFiles[$event['view']][$event['context']]
						= $component->params['joomla_component_headers'][$event['field']];
				}
			}
		}
	}

	/**
	 * Event Triggered in the compiler [on set Class Header]
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function jcb_ce_setClassHeader(&$context, &$event_context,
		&$view_name,
		&$headers
	) {
		if ($this->loadHeaders && isset($this->activeFiles[$view_name])
			&& isset($this->activeFiles[$view_name][$event_context]))
		{
			// we have default headers we actually need
			foreach ($headers as $n => $header)
			{
				// we check if this header is also set from the user
				if (strpos(
						$this->activeFiles[$view_name][$event_context], $header
					) !== false)
				{
					// since it is set, remove it here
					unset($headers[$n]);
				}
			}
			// now add the custom headers
			// yes they are below the defaults, unless overridden and removed above
			$headers[] = $this->activeFiles[$view_name][$event_context];
		}
	}

}
