<?php
/**
 * @package    Joomla.Component.Builder
 *
 * @created    30th April, 2015
 * @author     Llewellyn van der Merwe <http://www.joomlacomponentbuilder.com>
 * @github     Joomla Component Builder <https://github.com/vdm-io/Joomla-Component-Builder>
 * @copyright  Copyright (C) 2015 Vast Development Method. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * Extension - Componentbuilder Headers Compiler script file.
 *
 * @package PlgExtensionComponentbuilderHeadersCompiler
 */
class plgExtensionComponentbuilderHeadersCompilerInstallerScript
{

	/**
	 * Called before any type of action
	 *
	 * @param   string  $route  Which action is happening (install|uninstall|discover_install|update)
	 * @param   JAdapterInstance  $adapter  The object responsible for running this script
	 *
	 * @return  boolean  True on success
	 */
	public function preflight($route, JAdapterInstance $adapter)
	{
		// get application
		$app = JFactory::getApplication();

		// the default for both install and update
		$jversion = new JVersion();
		if (!$jversion->isCompatible('3.8.0'))
		{
			$app->enqueueMessage('Please upgrade to at least Joomla! 3.8.0 before continuing!', 'error');
			return false;
		}

		if ('install' === $route)
		{
			// check that componentbuilder is installed
			$pathToCore = JPATH_ADMINISTRATOR . '/components/com_componentbuilder/helpers/componentbuilder.php';
			if (!JFile::exists($pathToCore))
			{
				$app->enqueueMessage('Joomla Component Builder must first be installed from <a href="https://www.joomlacomponentbuilder.com/ " target="_blank">Joomla Component Builder</a>.', 'error');
				return false;
			}
			// load the helper class
			JLoader::register('ComponentbuilderHelper', JPATH_ADMINISTRATOR . '/components/com_componentbuilder/helpers/componentbuilder.php');
			// block install
			$blockInstall = true;
			// check the version of JCB
			$manifest = ComponentbuilderHelper::manifest();
			if (isset($manifest->version) && strpos($manifest->version, '.') !== false)
			{
				// get the version
				$jcbVersion = explode('.', $manifest->version);
				// check that we have JCB 2.12.6 or higher installed
				if (count($jcbVersion) == 3 && $jcbVersion[0] >= 2 && (($jcbVersion[1] == 12 && $jcbVersion[2] >= 6) || $jcbVersion[1] > 12))
				{
					$blockInstall = false;
				}
			}
			// allow install if all conditions are met
			if ($blockInstall)
			{
				$app->enqueueMessage('Please upgrade to JCB 2.12.6 or higher before installing this plugin.', 'error');
				return false;
			}
		}

		return true;
	}
}
