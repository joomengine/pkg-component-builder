<?php
/**
 * @package    Joomla.Component.Builder
 *
 * @created    30th April, 2015
 * @author     Llewellyn van der Merwe <http://www.joomlacomponentbuilder.com>
 * @github     Joomla Component Builder <https://github.com/vdm-io/Joomla-Component-Builder>
 * @copyright  Copyright (C) 2015 Vast Development Method. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Application\CMSApplication;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Registry\Registry;

JLoader::register('ComponentbuilderHelper', JPATH_ADMINISTRATOR . '/components/com_componentbuilder/helpers/componentbuilder.php');

/**
 * Extension - Componentbuilder Field Ordering Compiler plugin.
 *
 * @package   ComponentbuilderFieldOrderingCompiler
 * @since     1.0.0
 */
class PlgExtensionComponentbuilderFieldOrderingCompiler extends CMSPlugin
{
	/**
	 * Global switch to see if component have need of field ordering.
	 *
	 * @var    boolean
	 * @since  1.0.0
	 */
	protected  $loadFieldordering = false;

	/**
	 * The Views active with default ordering options
	 *
	 * @var    array
	 * @since  1.0.0
	 */
	protected  $activeViews = array();

	/**
	 * Event Triggered in the compiler [on Before Model View Data]
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function jcb_ce_onBeforeModelViewData(&$context, &$view, &$placeholders)
	{
		// add the privacy
		$view->params = (isset($view->params) && ComponentbuilderHelper::checkJson($view->params)) ? json_decode($view->params, true) : $view->params;
		if (ComponentbuilderHelper::checkArray($view->params) && isset($view->params['fieldordering']) && ComponentbuilderHelper::checkArray($view->params['fieldordering']))
		{
			if ($view->params['fieldordering']['add_admin_ordering'] == 1
				|| $view->params['fieldordering']['add_linked_ordering'] == 1)
			{
				// activate the load of the privacy plugin
				$this->loadFieldordering = true;
				// setup the view key name
				$name_list   = ComponentbuilderHelper::safeString($view->name_list);
				// load the admin view details
				$this->activeViews[$name_list] = $view->params['fieldordering'];
			}
		}
	}

	/**
	 * Event Triggered in the compiler [on After Get]
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function jcb_ce_onAfterGet(&$context, $compiler)
	{
		// check if this component needs a privacy plugin loaded
		if ($this->loadFieldordering)
		{
			// move the data to the compiler
			$compiler->viewsDefaultOrdering =& $this->activeViews;
		}
	}

}
