<?php
/**
 * @package    Joomla.Component.Builder
 *
 * @created    4th September 2022
 * @author     Llewellyn van der Merwe <https://dev.vdm.io>
 * @git        Joomla Component Builder <https://git.vdm.dev/joomla/Component-Builder>
 * @copyright  Copyright (C) 2015 Vast Development Method. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this JCB template file (EVER)
defined('_JCB_TEMPLATE') or die;
?>
###BOM###

###ADMIN_VIEWS_HEADER###

// No direct access to this file
defined('_JEXEC') or die;###LICENSE_LOCKED_DEFINED###

if ($this->saveOrder)
{
	$saveOrderingUrl = 'index.php?option=com_###component###&task=###views###.saveOrderAjax&tmpl=component';
	Joomla___34690c75_1090_47eb_8c06_7228dc7eedd6___Power::_('sortablelist.sortable', '###view###List', 'adminForm', strtolower($this->listDirn), $saveOrderingUrl);
}
?>
###VIEWS_DEFAULT_BODY######VIEWS_FOOTER_SCRIPT###
