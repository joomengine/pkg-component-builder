<?php
/**
 * @package    Joomla.Component.Builder
 *
 * @created    30th April, 2015
 * @author     Llewellyn van der Merwe <https://dev.vdm.io>
 * @git        Joomla Component Builder <https://git.vdm.dev/joomla/Component-Builder>
 * @copyright  Copyright (C) 2015 Vast Development Method. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * Content - Componentbuilder Component Dashboard Headers Tabs script file.
 *
 * @package PlgContentComponentbuilderComponentDashboardHeadersTabs
 */
class plgContentComponentbuilderComponentDashboardHeadersTabsInstallerScript
{

	/**
	 * Called before any type of action
	 *
	 * @param   string  $route  Which action is happening (install|uninstall|discover_install|update)
	 * @param   Joomla\CMS\Installer\InstallerAdapter  $adapter  The object responsible for running this script
	 *
	 * @return  boolean  True on success
	 */
	public function preflight($route, $adapter)
	{
		// get application
		$app = JFactory::getApplication();

		// the default for both install and update
		$jversion = new JVersion();
		if (!$jversion->isCompatible('3.8.0'))
		{
			$app->enqueueMessage('Please upgrade to at least Joomla! 3.8.0 before continuing!', 'error');
			return false;
		}

		if ('install' === $route)
		{
// needs fix


			// check that componentbuilder is installed
			$pathToCore = JPATH_ADMINISTRATOR . '/components/com_componentbuilder/helpers/componentbuilder.php';
			if (!JFile::exists($pathToCore))
			{
				$app->enqueueMessage('Joomla Component Builder must first be installed from <a href="https://www.joomlacomponentbuilder.com/ " target="_blank">Joomla Component Builder</a>.', 'error');
				return false;
			}

			// load the helper class
			JLoader::register('ComponentbuilderHelper', JPATH_ADMINISTRATOR . '/components/com_componentbuilder/helpers/componentbuilder.php');

			// block install
			$blockInstall = true;

			// check the version of JCB
			$manifest = ComponentbuilderHelper::manifest();
			if (isset($manifest->version) && strpos($manifest->version, '.') !== false)
			{
				// get the version
				$jcbVersion = explode('.', $manifest->version);
				// check that we have JCB 3.0.0 or higher installed
				if (count($jcbVersion) == 3 && $jcbVersion[0] >= 3 &&
					(
						($jcbVersion[0] == 3 && $jcbVersion[1] == 0 && $jcbVersion[2] >= 0) ||
						($jcbVersion[0] == 3 && $jcbVersion[1] > 0) ||
						$jcbVersion[0] > 3)
					)
				{
					$blockInstall = false;
				}
			}

			// allow install if all conditions are met
			if ($blockInstall)
			{
				$app->enqueueMessage('Please upgrade to JCB v3.0.0 or higher before installing this plugin.', 'error');
				return false;
			}


			// check that componentbuilder is installed
			$pathToCore = JPATH_ADMINISTRATOR . '/components/com_componentbuilder/helpers/componentbuilder.php';
			if (!JFile::exists($pathToCore))
			{
				$app->enqueueMessage('Joomla Component Builder must first be installed from <a href="https://www.joomlacomponentbuilder.com/ " target="_blank">Joomla Component Builder</a>.', 'error');
				return false;
			}
			// load the helper class
			JLoader::register('ComponentbuilderHelper', JPATH_ADMINISTRATOR . '/components/com_componentbuilder/helpers/componentbuilder.php');
			// block install
			$blockInstall = true;
			// check the version of JCB
			$manifest = ComponentbuilderHelper::manifest();
			if (isset($manifest->version) && strpos($manifest->version, '.') !== false)
			{
				// get the version
				$jcbVersion = explode('.', $manifest->version);
				// check that we have JCB 2.10.13 or higher installed
				if (count($jcbVersion) == 3 && (($jcbVersion[0] == 2 && $jcbVersion[1] >= 10 && (($jcbVersion[1] == 10 && $jcbVersion[2] >= 13) || ($jcbVersion[1] > 10))) || $jcbVersion[0] >= 3))
				{
					$blockInstall = false;
				}
			}
			// allow install if all conditions are met
			if ($blockInstall)
			{
				$app->enqueueMessage('Please upgrade to JCB 2.10.13 or higher before installing this plugin.', 'error');
				return false;
			}

			// check that componentbuilder is installed
			$pathToCore = JPATH_ADMINISTRATOR . '/components/com_componentbuilder/helpers/componentbuilder.php';
			if (!JFile::exists($pathToCore))
			{
				$app->enqueueMessage('Joomla Component Builder must first be installed from <a href="https://www.joomlacomponentbuilder.com/ " target="_blank">Joomla Component Builder</a>.', 'error');
				return false;
			}

			// check that componentbuilder is installed
			$pathToCore = JPATH_ADMINISTRATOR . '/components/com_componentbuilder/helpers/componentbuilder.php';
			if (!JFile::exists($pathToCore))
			{
				$app->enqueueMessage('Joomla Component Builder must first be installed from <a href="https://www.joomlacomponentbuilder.com/ " target="_blank">Joomla Component Builder</a>.', 'error');
				return false;
			}

			// check that componentbuilder is installed
			$pathToCore = JPATH_ADMINISTRATOR . '/components/com_componentbuilder/helpers/componentbuilder.php';
			if (!JFile::exists($pathToCore))
			{
				$app->enqueueMessage('Joomla Component Builder must first be installed from <a href="https://www.joomlacomponentbuilder.com/ " target="_blank">Joomla Component Builder</a>.', 'error');
				return false;
			}

			// check that componentbuilder is installed
			$pathToCore = JPATH_ADMINISTRATOR . '/components/com_componentbuilder/helpers/componentbuilder.php';
			if (!JFile::exists($pathToCore))
			{
				$app->enqueueMessage('Joomla Component Builder must first be installed from <a href="https://www.joomlacomponentbuilder.com/ " target="_blank">Joomla Component Builder</a>.', 'error');
				return false;
			}


			// check that componentbuilder is installed
			$pathToCore = JPATH_ADMINISTRATOR . '/components/com_componentbuilder/helpers/componentbuilder.php';
			if (!JFile::exists($pathToCore))
			{
				$app->enqueueMessage('Joomla Component Builder must first be installed from <a href="https://www.joomlacomponentbuilder.com/ " target="_blank">Joomla Component Builder</a>.', 'error');
				return false;
			}

			// load the helper class
			JLoader::register('ComponentbuilderHelper', JPATH_ADMINISTRATOR . '/components/com_componentbuilder/helpers/componentbuilder.php');

			// block install
			$blockInstall = true;

			// check the version of JCB
			$manifest = ComponentbuilderHelper::manifest();
			if (isset($manifest->version) && strpos($manifest->version, '.') !== false)
			{
				// get the version
				$jcbVersion = explode('.', $manifest->version);
				// check that we have JCB 3.0.0 or higher installed
				if (count($jcbVersion) == 3 && $jcbVersion[0] >= 3 &&
					(
						($jcbVersion[0] == 3 && $jcbVersion[1] == 0 && $jcbVersion[2] >= 0) ||
						($jcbVersion[0] == 3 && $jcbVersion[1] > 0) ||
						$jcbVersion[0] > 3)
					)
				{
					$blockInstall = false;
				}
			}

			// allow install if all conditions are met
			if ($blockInstall)
			{
				$app->enqueueMessage('Please upgrade to JCB v3.0.0 or higher before installing this plugin.', 'error');
				return false;
			}



			// check that componentbuilder is installed
			$pathToCore = JPATH_ADMINISTRATOR . '/components/com_componentbuilder/helpers/componentbuilder.php';
			if (!JFile::exists($pathToCore))
			{
				$app->enqueueMessage('Joomla Component Builder must first be installed from <a href="https://www.joomlacomponentbuilder.com/ " target="_blank">Joomla Component Builder</a>.', 'error');
				return false;
			}

			// load the helper class
			JLoader::register('ComponentbuilderHelper', JPATH_ADMINISTRATOR . '/components/com_componentbuilder/helpers/componentbuilder.php');

			// block install
			$blockInstall = true;

			// check the version of JCB
			$manifest = ComponentbuilderHelper::manifest();
			if (isset($manifest->version) && strpos($manifest->version, '.') !== false)
			{
				// get the version
				$jcbVersion = explode('.', $manifest->version);
				// check that we have JCB 3.0.0 or higher installed
				if (count($jcbVersion) == 3 && $jcbVersion[0] >= 3 &&
					(
						($jcbVersion[0] == 3 && $jcbVersion[1] == 0 && $jcbVersion[2] >= 0) ||
						($jcbVersion[0] == 3 && $jcbVersion[1] > 0) ||
						$jcbVersion[0] > 3)
					)
				{
					$blockInstall = false;
				}
			}

			// allow install if all conditions are met
			if ($blockInstall)
			{
				$app->enqueueMessage('Please upgrade to JCB v3.0.0 or higher before installing this plugin.', 'error');
				return false;
			}



			// check that componentbuilder is installed
			$pathToCore = JPATH_ADMINISTRATOR . '/components/com_componentbuilder/helpers/componentbuilder.php';
			if (!JFile::exists($pathToCore))
			{
				$app->enqueueMessage('Joomla Component Builder must first be installed from <a href="https://www.joomlacomponentbuilder.com/ " target="_blank">Joomla Component Builder</a>.', 'error');
				return false;
			}

			// load the helper class
			JLoader::register('ComponentbuilderHelper', JPATH_ADMINISTRATOR . '/components/com_componentbuilder/helpers/componentbuilder.php');

			// block install
			$blockInstall = true;

			// check the version of JCB
			$manifest = ComponentbuilderHelper::manifest();
			if (isset($manifest->version) && strpos($manifest->version, '.') !== false)
			{
				// get the version
				$jcbVersion = explode('.', $manifest->version);
				// check that we have JCB 3.1.18 or higher installed
				if (count($jcbVersion) == 3 && $jcbVersion[0] >= 3 &&
					(
						($jcbVersion[0] == 3 && $jcbVersion[1] == 1 && $jcbVersion[2] >= 18) ||
						($jcbVersion[0] == 3 && $jcbVersion[1] > 1) ||
						$jcbVersion[0] > 3)
					)
				{
					$blockInstall = false;
				}
			}

			// allow install if all conditions are met
			if ($blockInstall)
			{
				$app->enqueueMessage('Please upgrade to JCB v3.1.18 or higher before installing this plugin.', 'error');
				return false;
			}



			// check that componentbuilder is installed
			$pathToCore = JPATH_ADMINISTRATOR . '/components/com_componentbuilder/helpers/componentbuilder.php';
			if (!JFile::exists($pathToCore))
			{
				$app->enqueueMessage('Joomla Component Builder must first be installed from <a href="https://www.joomlacomponentbuilder.com/ " target="_blank">Joomla Component Builder</a>.', 'error');
				return false;
			}

			// load the helper class
			JLoader::register('ComponentbuilderHelper', JPATH_ADMINISTRATOR . '/components/com_componentbuilder/helpers/componentbuilder.php');

			// block install
			$blockInstall = true;

			// check the version of JCB
			$manifest = ComponentbuilderHelper::manifest();
			if (isset($manifest->version) && strpos($manifest->version, '.') !== false)
			{
				// get the version
				$jcbVersion = explode('.', $manifest->version);
				// check that we have JCB 3.0.14 or higher installed
				if (count($jcbVersion) == 3 && $jcbVersion[0] >= 3 &&
					(
						($jcbVersion[0] == 3 && $jcbVersion[1] == 0 && $jcbVersion[2] >= 14) ||
						($jcbVersion[0] == 3 && $jcbVersion[1] > 0) ||
						$jcbVersion[0] > 3)
					)
				{
					$blockInstall = false;
				}
			}

			// allow install if all conditions are met
			if ($blockInstall)
			{
				$app->enqueueMessage('Please upgrade to JCB v3.0.14 or higher before installing this plugin.', 'error');
				return false;
			}

		}

		return true;
	}
}
