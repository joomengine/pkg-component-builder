# v6.1.6

- Add Health Check buttons to the JCB Compiler and Component list view to verify system PHP configuration.
- Add the Toolbar Custom Buttons subform to the Global Subform settings for improved usability and presentation.
- Fix the Field edit view to ensure full compliance with Joomla 6 standards and updated UI/UX conventions.
- Begin migration from UIkit to Bootstrap 5 to align JCB with Joomla 6+ standards.
- Complete Bootstrap 5 refactor of all primary views and core UI.
- Continue phased removal of UIkit with full transition planned for upcoming releases.
- Fix deprecated JText usage in Admin Custom Tabs area for Joomla 5+ compatibility. #1302
- Fix snippet loading for Joomla 6, improving reliability and removing legacy UIkit dependencies during migration.
- Introduced strict version-aware compilation to ensure libraries are only included when explicitly defined for Joomla 6.
- Disabled automatic UIkit injection for Joomla 6, preventing auto-loading across custom admin views, site views, templates, and layouts.
- Migrate Search view for J6 to use Bootstrap and Joomla-native HTML and JavaScript.
- Remove all manually linked Bootstrap v4 assets from the component.
- Improve subform ordering fields for clearer display and better readability.
- Refactor the JavaScript waiting spinner to use solid, native JavaScript with improved page-loading handling.

# v5.1.6

- Add Health Check buttons to the JCB Compiler and Component list view to verify system PHP configuration.
- Add the Toolbar Custom Buttons subform to the Global Subform settings for improved usability and presentation.
- Fix the Field edit view to ensure full compliance with Joomla 6 standards and updated UI/UX conventions.
- Begin migration from UIkit to Bootstrap 5 to align JCB with Joomla 6+ standards.
- Complete Bootstrap 5 refactor of all primary views and core UI.
- Continue phased removal of UIkit with full transition planned for upcoming releases.
- Fix deprecated JText usage in Admin Custom Tabs area for Joomla 5+ compatibility. #1302
- Fix snippet loading for Joomla 6, improving reliability and removing legacy UIkit dependencies during migration.
- Introduced strict version-aware compilation to ensure libraries are only included when explicitly defined for Joomla 6.
- Disabled automatic UIkit injection for Joomla 6, preventing auto-loading across custom admin views, site views, templates, and layouts.
- Migrate Search view for J6 to use Bootstrap and Joomla-native HTML and JavaScript.
- Remove all manually linked Bootstrap v4 assets from the component.
- Improve subform ordering fields for clearer display and better readability.
- Refactor the JavaScript waiting spinner to use solid, native JavaScript with improved page-loading handling.

# v5.1.5

- Fix variable name mismatch for organization in the Network Resolve class. #1291
- Fix issue where Admin Field relations using custom code did not automatically include multiple fields as expected. #1293
- Fix issue where Admin Field relations did not correctly apply concatenation/glue options. #1294
- Refactor Compiler functions to improve maintainability and align with modern PHP coding best practices.
- Refactor the JCB Dashboard, introducing a modernized layout, improved usability, and full responsiveness across desktop, tablet, and mobile devices.
- Fix deprecated warnings triggered in the JCB CLI.
- Fix resolve PHP syntax errors and PHP 8.4 deprecations across codebase.
- Fix four fatal parse/compile errors.
- Fix implicit nullable parameter deprecations.

# v5.1.4

- Fix the linked [new] button to use the correct init_default params.
- Fix the Components list view to better display long website urls.
- Fix language text area css. #1264
- Refactor the JS selText method.
- Add fix for empty currentFullPath in the Structuresingle class.
- Fix the buildSelectPart method to not access an empty select value in the Queries class.
- Fix that ensure that we always load and int into loadUserById.
- Fix the subform permission behaviour to use removeField.
- Add version 6 to the version 5 update server, for easier upgrade path.
- Fixed linked admin views with New and New & Close buttons to correctly initialize fields using global unique IDs and default conventions.
- Resolved missing language strings when linked admin views are also configured as site edit views.
- Corrected misconfiguration of the isModal property for site-linked views to default to false since modals are not yet supported on the site area.
- Enhanced security in edit views by moving access validation into the model, ensuring protection even when Joomla bypasses the controller layer.
- Added user access verification logic in the model to prevent unauthorized direct item loading.
- Refactored the view class to introduce a class constructor that initializes key dependencies more reliably.
- Began aligning the view class structure with Joomla 6's updated MVC architecture for future compatibility.
- Improved initialization handling in the view to reduce dependency errors during rendering.
- Fixed a bug caused by missing option settings in the model configuration.
- Updated and refined the site view class for greater consistency with backend view logic.
- Continued progressive improvements across view classes to ensure compatibility with Joomla's evolving MVC patterns.
- Fix permission issue in the list view. #1266
- Refactor the list view buttons.
- Refactor the getActions helper method.
- Rename Custom Buttons tab to Toolbar for clearer grouping of toolbar functions. #1268
- Add options for overriding default toolbars in all Admin, Site, and Custom Admin Views. #1268
- Refactored toolbar into version specific classes to resolve getToolbar errors. #1267
- Added method to unify getDatabase handling across Joomla versions and prevent undefined method calls. #1270
- Fix php8.3 deprecation warnings in compiler templates. #1265
- Refactor and enhance the JCB Email Helper class for a more robust and maintainable design.
- Fix an issue where the Email Helper send() function was executed twice.
- Fix a issue where layouts added to the PHP Ajax Model were not loaded during compilation.
- Add new functionality to the toolbar override system, enabling the inclusion of custom buttons via placeholders.
- Fix the Compiler success message to display both build seconds and project weeks.
- Add Development Valuation Model to calculate JCB component pricing.
- Add functionality to push JCB packages to Self hosted Git system that uses a self signed SSL.
- Add functionality that will include Validation Rules linked to fields in JCB packages. #1273
- Refactor and Improve Router Helper Class to new standard Site Router practice.
- Refactor and Improve JCB Search engine for better searching of JCB areas.
- Fix bug in the search editor in JCB Search Engine.
- Fix issue where Custom Gets linked to a Site view did not ship correctly with JCB packages. #1272
- Fix issue where the Icon linked to a Custom Admin Menu did not ship with JCB packages. #1271
- Fix and Improve Normalize Class to better handle different files Linked to JCB packages. #1274
- Remove batch feature from JCB compiler Templates due to lack of use and outdated code.
- Refactor Utilities/Response classes for Joomla 6+ compatibility and improved version-agnostic behavior.
- Refactor the File Upload Manager to achieve improved maintainability, greater customization flexibility, and easier extensibility.
- Refactor the Item Importer to improve data management, structural clarity, and long-term maintainability of the import process.
- Add a Pull button to all main JCB entities, allowing a complete reset of a selected entity together with all entities linked to it from a selected remote repository.
- Add functionality to the compiler to automatically pull missing entities from a remote repository when they are referenced by a component but not present locally in JCB.
- Refactor the Packaging Engine into separate set and get classes to improve separation of concerns, readability, and overall maintainability.
- Refactor and restructure the demo console item import plugin to improve usability, maintainability, and reusability across other areas of JCB.
- Refactor the Compiler to remove deprecated code paths and legacy classes that are no longer maintained.
- Add new Compiler Classes to modernise ancient tech previously embedded in the compiler and replace it with a clean, modern architecture.
- Add a dedicated CLI plugin to the JCB core, enabling direct interaction with JCB through the Joomla CLI console.
- Add structured CLI commands and options to Init, Reset, Push, and Pull JCB entities via the Joomla CLI.
- Add full support for compiling Components directly via the CLI, enabling automated and headless build workflows.
- Add functionality to place Super Power classes into the component src folder for both Admin and Site areas, using the correct namespaced structure.
- Add functionality to the CLI compiler to directly install compiled components and apply compiler options used during compilation.
- Add functionality to the compiler to automatically pull a missing component from a remote repository when a compilation is triggered and the component is not locally available.
- Add functionality to add and replace classes in module and plugin src folders that are linked to a component, when using correct namespace resolution.
- Add a Documentation tab to the Joomla Component Builder dashboard.
- Fix an issue with the JCB version notice on Joomla 5.
- Fix an issue where components without a component image failed to compile successfully. #1282
- Add functionality for importing translated language strings directly into the Language Translations area of JCB.
- Fix issue where the Language Translations export button was not displayed due to recent toolbar changes.
- Fix a bug that caused language filters to malfunction because of a broken field configuration. #1278
- Fix issue where components without a layout added to the Component failed to compile correctly. #1132

# v5.1.3

- Stability update addressing a post-release field issue. #1262
- Fix a security vulnerability in custom code redirect URL validation.
- Add an alert to the Compiler view when no Components exist. #1263

# v5.1.2

- Fix the template and layout linker for packages.
- Add native module builder for Joomla 4/5
- Refactor dynamic get methods into dedicated classes
- Move Joomla DB handling into compiler injector flow
- Fix auto-check(in) method for Joomla 4/5 compatibility
- Migrates view HTML classes to use getModel() directly instead of the deprecated magic get() calls to model methods.
- Refactores event handling (contentPrepare, titlePrepare, contentBeforeDisplay, contentAfterDisplay) to use Joomla 5's native event dispatcher via the model's new getDispatcher() method.
- Updates table classes to properly support NULL values, both in the store() method and in table variable definitions. #1245
- Extractes the setAutoCheckIn() and setCheckInCall() logic into a dedicated CheckInNow class for cleaner design.
- Replace all direct $app->input property calls with the recommended $app->getInput() method across the entire codebase.
- Add Joomla 6 build option
- Fix Custom Rule Validation Bug
- Unpublish Joomla 6 Backward Compatibility Plugin
- Refactors the Compiler Model by dropping deprecated calls and adopting Joomla 5+ conventions
- Refactors Compiler Controller to remove deprecated usage and follow Joomla 5+ best practices
- Adds check to ensure expert mode subforms in the Demo Component remain set and unchanged when user lacks edit permissions
- Improves validation handling of Fields by ensuring field validation rules are properly registered
- Replace StringHelper with the correct Super Power key so it loads in the Compiler Controller
- Add functionality to add component changelog into the package if configured.
- Refactor PHP classes for building HTML view files in admin and site views to align with Joomla 5+ standards.
- Fix issues in the site view HtmlView caused by the refactor, including missing class calls and outdated function references.
- Fix issue where the DatabaseSchemaCheckAll pulled all Component Builder tables into DB on install. #1253
- Fix issue in the Dynamic Get when the value key is 0 it wouldn't add the 'WHERE' statement to the generated code. #1254
- Change radio buttons with a empty option to save Datatype CHAR instead of TINYINT as other radio buttons. #1252
- Add extra xml details to Modules built with JCB that adds advance options to the module. #1248
- Remove setDocumentTitle method from the admin view since it is not being used by Joomla. #1255
- Refactor compiler Move file update to classes.
- Refactor compiler Move plugin and module fields and rules files mover to classes.
- Fix issue where custom powers was not added to PowerloaderHelper. #1256
- Fix normalization issue when compiling on Windows systems. #1219
- Fix installer issue on Joomla 6 where components containing multiple plugins failed during installation.
- Completely refactors the Compiler Dashboard to align with Joomla 5+ architecture and Bootstrap 5 standards.
- Add a default VARCHAR(36) length to easily create fields intended to store GUID values.
- Update the file uploader in the Demo Component for more dynamic file display and naming.
- Update the SQL file dump generator to handle large SQL dumps in batches, ensuring safe and reliable database imports.
- Update example hints in the field expert mode options.

# v5.1.1

- Move all banners to GitHub.
- Adds library phpspreadsheet to JCB.
- Adds import item example to demo component.
- Updates the Superpower class with the GetRemote class in the plugin.
- Ensures the super power autoloader triggers the correct repositories.
- Adds the ModalSelect fieldtype to Joomla Component Builder - J5
- Adds the Data Import Function to the Demo Component.
- Adds new country related tables and fields to the Demo Component.
- Resolves the Database Updating issue in the compiler. #1212,#1209
- Adds the Component Commands Plugin to the CLI for Import of spreadsheet data-sets.
- Add edit and create options to the ModalSelect Field (in Joomla 5)
- Add all needed Powers to the release package, to speed-up the build of the demo component.
- Refactor initialization flow to accommodate future scalability and integration with all designated areas.
- Refactor the Creator Builders class.
- Refactor the FieldString and FieldXML classes.
- Add JCB new package engine.
- Enhance operator support in dynamic get system. Relates to issue #1226.
- Fixes issue with loading the Component Builder Wiki.
- Adds advanced version update notice to the Component Builder Dashboard.
- Completely refactors the class that builds the Component Dashboard. #1134
- Fix the FieldXML interface mismatch. #1228
- Adds Initialize, Reset, and Push functionality to the Repository entities.
- Completely refactors the SQL tweaks and SQL dump classes.
- Fix bug in the filter of Languages by linked entities. #1230
- Adds option to export Language Translations.

# v5.1.0

- Add [AllowDynamicProperties] in the base view class for J5
- Move the _prepareDocument  above the display call in the base view class
- Remove all backward compatibility issues, so JCB will not need the [Backward Compatibility] plugin to run.
- Added new import powers for custom import of spreadsheets.
- Move the setDocument and _prepareDocument above the display in the site view and custom admin view.
- Update the trashhelper layout to work in Joomla 5.
- Add AllowDynamicProperties (Joomla 4+5) to view class to allow Custom Dynamic Get methods to work without issues.
- Fix Save failed issue in dynamicGet. #1148
- Move all [TEXT, EDITOR, TEXTAREA] fields from [NOT NULL] to [NULL]
- Add the DateHelper class and improve the date methods.
- Add simple SessionHelper class.
- Add first classes for the new import engine.
- Improve the [VDM Registry] to be Joomla Registry Compatible
- Move all registries to the [VDM Registry] class
- Fix Checked Out to be null and not 0. (#1194)
- Fix created_by, modified_by, checked_out fields in the compiler of the SQL. (#1194)
- Update all core date fields in table class. (#1188)
- Update created_by, modified_by, checked_out fields in table class.
- Implementation of the decentralized Super-Power CORE repository network. (#1190)
- Fix the noticeboard to display Llewellyn's Joomla Social feed
- Started compiling JCB5 on Joomla 5 with PHP 8.2
- Add init_defaults option for dynamic form selection setup (to int new items with default values dynamically)
- Update all JCB 5 tables to utf8mb4_unicode_ci collation if misaligned
- Move all internal ID linking to GUID inside of JCB 5
- Updated the admin-tab-fields in add-fields view. #1205
- Remove Custom Import Tab from admin view
- Improved the customcode and placeholder search features

# v5.0.3

- Add [push] option to powers area.
- Fix error in [Save As Copy] functionality for the library. #1162
- Fix error when no components exist. #1164
- Fix search page error caused by File class.
- Fix UserGroupList compiler triggers. #1100
- Add power integration field type with [init, reset, push] options.
- Fix default database fields to allow NULL values. #1169
- Fix power list field to support search functionality. #1167
- Expand Demo component in JCB v4 to include advanced features.
- Fix missing working path in zip creation.
- Fix dynamic retrieval for the demo site view.
- Fix demo site view to display files.
- Fix field type initialization message.
- Fix type-agnostic comparisons by casting to CHAR in dynamic get joins.
- Fix dynamic download for site area to use correct namespace.
- Fix missing edit button on fields in related views.
- Fix dashboard display issues.
- Restore search option in the [use] field for related views.
- Fix namespace issue causing linker to break.

# v5.0.2

- Fix site view form missing classes in J4+
- Fix permissions tab in items in J4+
- Fix site display controller checkEditId function in J4+
- Add class methods to the HtmlView classes in J4+
- Fix broken toolbar call in HtmlView in J4+
- Fix missing scripts and styles fields and methods in the site admin view model
- Update subform field layout across JCB for cleaner look
- Remove expansion feature
- Fix helper area
- Fix database mySql update in J4+
- Remove phpspreadsheet completely from Joomla 4+
- Add option to use powers in preflight event in the installer class
- Fix abstract schema class function check default index warring
- Fix dynamicGet so that the table values will load again. #1155
- Add more pure JS to the dynamic get area
- Add native plugin builder for Joomla 4 & 5
- Add basic API for admin views

# v5.0.1

- Fix auto build from SQL in Joomla 5.
- Fix permission issue for admin views.
- Add in JCB gitea push feature to help maintain JCB core features.
- Add extending options to interfaces.
- Change the extendsinterfaces field to allow null, #1139
- Update the Schema class to also update null mismatching if needed
- Add repositories for better integration with gitea
- Refactored the Data classes
- Add new Data classes
- Add new subform classes
- Fix registry class methods return type
- Update all list and custom fields to use the new layouts
- Add push options to Joomla Power
- Complete the Joomla Power Init and Reset features
- Fix Gitea Contents class functions
- Fix subform set methods
- Improved the Joomla Power Push path
- Fix the metadata, metadesc, metakey database issue
- Fix function mismatch call in the compiler power class.
- Fix init feature to only add missing powers
- Fix controller postSaveHook function, for correct model class in Joomla 4 and 5
- Fix app instances (mismatch) in the install script and schema class when installing from CLI
- Add option to use placeholders in Joomla Power namespaces.
- Fix subform layout of uikit in JCB

# v5.0.0

- Fix the plug-in installer script builder bug #1067
- Fix Event triggers for Joomla 4 and 5 builds.
- Add fix to the update script, so that upgrading JCB from Joomla 4 to 5 will not fail.
- Fix plugin field selection
- Fix plugin params tab layout
- Add issue templates
- Force autoloader to always load
- Fix repeatable layout #1076
- Add Factory class to the J5 Event class. #1093
- Fix customfilelist field to conform to the new namespacing conventions. #1094
- Add menus for languages, servers, get snippets to J5 #1095
- Fix [Set String Value] in placeholder table to store the value as a base64 string.
- Fix the search area layout.
- Fix the search area code line selection.
- Fix the input edit button for custom fields.
- Add the new layout to list fields (GUI UPDATE)
- Start fixing the field view in Joomla 5. #1096
- Add power path override option on component level.
- Fix the sql build feature. #1032
- Add the compiler menu back.
- Fix the CustomfolderlistField #1094
- Add view list and single name fix.
- Add component code name fix.
- Add reset list of powers.
- Add Joomla powers for namespace dynamic management.
- Add fallback option to ensure that all JCB tables and fields exist.
- Move the powers autoloader to its own file.
- Fix the media field size limitation. #1109
- Add dynamic datatype update to schema field check.
- Fix version_update column size.
- Improved the Schema Table update engine.
- Improved the Schema Table update engine (more).
- Fix autoloader timing, and loading.
- Implement the Joomla Powers in JCB code, to move away from JClasses.
- Remove the SQL update, to only use the Schema updates of table columns to avoid collusion.
- Fix the admin.css file loading on dashboard. #1112
- Fix dynamic get data-type default to 0. #1110
- Fix the missing model call. #1114
- Fix the wrong $date call. #1115
- Add the BaseDatabaseModel use statement to custom site view controller. #1119
- Fix the customfolderlist field. #1120

# v4.1.5

- Add Health Check buttons to the JCB Compiler and Component list view to verify system PHP configuration.
- Add the Toolbar Custom Buttons subform to the Global Subform settings for improved usability and presentation.
- Fix the Field edit view to ensure full compliance with Joomla 6 standards and updated UI/UX conventions.
- Begin migration from UIkit to Bootstrap 5 to align JCB with Joomla 6+ standards.
- Complete Bootstrap 5 refactor of all primary views and core UI.
- Continue phased removal of UIkit with full transition planned for upcoming releases.
- Fix deprecated JText usage in Admin Custom Tabs area for Joomla 5+ compatibility. #1302
- Fix snippet loading for Joomla 6, improving reliability and removing legacy UIkit dependencies during migration.
- Introduced strict version-aware compilation to ensure libraries are only included when explicitly defined for Joomla 6.
- Disabled automatic UIkit injection for Joomla 6, preventing auto-loading across custom admin views, site views, templates, and layouts.
- Migrate Search view for J6 to use Bootstrap and Joomla-native HTML and JavaScript.
- Remove all manually linked Bootstrap v4 assets from the component.
- Improve subform ordering fields for clearer display and better readability.
- Refactor the JavaScript waiting spinner to use solid, native JavaScript with improved page-loading handling.

# v3.2.5

- Add [AllowDynamicProperties] in the base view class for J5
- Move the _prepareDocument  above the display call in the base view class
- Remove all backward compatibility issues, so JCB will not need the [Backward Compatibility] plugin to run.
- Added new import powers for custom import of spreadsheets.
- Move the setDocument and _prepareDocument above the display in the site view and custom admin view.
- Update the trashhelper layout to work in Joomla 5.
- Add AllowDynamicProperties (Joomla 4+5) to view class to allow Custom Dynamic Get methods to work without issues.
- Fix Save failed issue in dynamicGet. #1148
- Move all [TEXT, EDITOR, TEXTAREA] fields from [NOT NULL] to [NULL]
- Add the DateHelper class and improve the date methods.
- Add simple SessionHelper class.
- Add first classes for the new import engine.
- Improve the [VDM Registry] to be Joomla Registry Compatible
- Move all registries to the [VDM Registry] class
- Fix Checked Out to be null and not 0. (#1194)
- Fix created_by, modified_by, checked_out fields in the compiler of the SQL. (#1194)
- Update all core date fields in table class. (#1188)
- Update created_by, modified_by, checked_out fields in table class.
- Implementation of the decentralized Super-Power CORE repository network. (#1190)
- Fix the noticeboard to display Llewellyn's Joomla Social feed