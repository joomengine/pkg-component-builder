<?php
/**
 * @package    Joomla.Component.Builder
 *
 * @created    30th April, 2015
 * @author     Llewellyn van der Merwe <http://www.joomlacomponentbuilder.com>
 * @github     Joomla Component Builder <https://github.com/vdm-io/Joomla-Component-Builder>
 * @copyright  Copyright (C) 2015 Vast Development Method. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Application\CMSApplication;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Registry\Registry;

JLoader::register('ComponentbuilderHelper', JPATH_ADMINISTRATOR . '/components/com_componentbuilder/helpers/componentbuilder.php');

/**
 * Extension - Componentbuilder ActionLog Compiler plugin.
 *
 * @package   ComponentbuilderActionLogCompiler
 * @since     1.0.2
 */
class PlgExtensionComponentbuilderActionLogCompiler extends CMSPlugin
{
	/**
	 * Affects constructor behavior. If true, language files will be loaded automatically.
	 *
	 * @var    boolean
	 * @since  1.0.0
	 */
	protected  $autoloadLanguage = true;

	/**
	 * The language string builder
	 * 
	 * @var     array
	 */
	protected $languageArray = array();

	/**
	 * The hash placeholder
	 * 
	 * @var     string
	 */
	protected $hhh = '#' . '#' . '#';

	/**
	 * The open bracket placeholder
	 * 
	 * @var     string
	 */
	protected $bbb = '[' . '[' . '[';

	/**
	 * The close bracket placeholder
	 * 
	 * @var     string
	 */
	protected $ddd = ']' . ']' . ']';

	/*
	 * The line numbers Switch
	 * 
	 * @var      boolean
	 */
	protected $debugLinenr = false;

	/**
	 * The Scripts
	 * 
	 * @var   array
	 */
	protected $scriptsArray = array('POSTINSTALLSCRIPT' => array(), 'POSTUPDATESCRIPT' => array(), 'UNINSTALLSCRIPT' => array());

	/**
	 * Event Triggered in the compiler [on Before Get Component Data]
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function jcb_ce_onBeforeGetComponentData(&$context, $compiler)
	{
		if ($this->componentActive($context))
		{
			// sync needed compiler class properties with this plugin class
			$this->debugLinenr = $compiler->debugLinenr;
			$this->hhh = $compiler->hhh;
			$this->bbb = $compiler->bbb;
			$this->ddd = $compiler->ddd;
		}
	}

	/**
	 * Event Triggered in the compiler [on After Get Component Data]
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function jcb_ce_onAfterGetComponentData(&$context, $compiler)
	{
		if ($this->componentActive($context) && ComponentbuilderHelper::checkArray($this->languageArray))
		{
			foreach($this->languageArray as $key => $string)
			{
				$compiler->setLangContent('admin', $key, $string);
			}
		}
	}

	/**
	 * Event Triggered in the compiler [on After Build Files Content]
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function jcb_ce_onAfterBuildFilesContent(&$context, &$componentData, &$fileContentStatic, &$fileContentDynamic, &$placeholders, &$hhh)
	{
		if ($this->componentActive($context))
		{
			// now load the script strings to the  component
			foreach ($this->scriptsArray as $target => &$bucket)
			{
				// add the component main target script
				$fileContentStatic[$hhh. $target . $hhh] .= $this->{'getMain' . $target}($placeholders);
				// add the component views target scripts
				if (ComponentbuilderHelper::checkArray($bucket))
				{
					$fileContentStatic[$hhh. $target . $hhh] .= implode('', $bucket);
				}
			}
		}
	}

	/**
	 * Event Triggered in the compiler [on After Model View Data]
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function jcb_ce_onAfterModelViewData(&$context, &$view, &$placeholders)
	{
		// add the better integration with action log
		if ($this->componentActive($context) &&ComponentbuilderHelper::checkArray($view->fields))
		{
			foreach ($view->fields as $field)
			{
				if (isset($field['title']) && $field['title'] == 1)
				{
					$title_holder = $field['base_name'];
					break;
				}
			}
			// if not found try again
			if (!isset($title_holder))
			{
				foreach ($view->fields as $field)
				{
					if (isset($field['list']) && $field['list'] == 1 &&
						isset($field['order_list']) && $field['order_list'] == 1 &&
						isset($field['link']) && $field['link'] == 1)
					{
						$title_holder = $field['base_name'];
						break;
					}
				}
			}
			// none title set
			$placeholders['<<<MAIN_TITLE>>>'] = '';
			// if found update placeholder
			if (isset($title_holder))
			{
				// set main title
				$placeholders['<<<MAIN_TITLE>>>'] = $title_holder;
			}
			else
			{
				// fall back on ID
				$placeholders['<<<MAIN_TITLE>>>'] = 'id';
			}
			// now load the script strings
			foreach ($this->scriptsArray as $target => &$bucket)
			{
				$bucket[] = $this->{'getView' . $target}($placeholders);
			}
			// just remove it again
			unset($placeholders['<<<MAIN_TITLE>>>']);
			// set language string
			$this->languageArray[$placeholders[$this->bbb . "LANG_PREFIX" . $this->ddd] . '_TYPE_' . $placeholders[$this->bbb . "VIEW" . $this->ddd]] = $view->name_single;
		}
	}

	/**
	 * get the Main Post Install Script
	 * 
	 * @return  string
	 * 
	 */
	protected function getMainPOSTINSTALLSCRIPT(&$placeholders)
	{
		$script = PHP_EOL . PHP_EOL . $this->_t(3) . "//" . $this->setLine(__LINE__) . " Set db if not set already.";
		$script .= PHP_EOL . $this->_t(3) . "if (!isset(\$db))";
		$script .= PHP_EOL . $this->_t(3) . "{";
		$script .= PHP_EOL . $this->_t(4) . "\$db = JFactory::getDbo();";
		$script .= PHP_EOL . $this->_t(3) . "}";

		$script .= PHP_EOL . $this->_t(3) . "//" . $this->setLine(__LINE__) . " Create the " . $this->bbb . "component" . $this->ddd . " action logs extensions object.";
		$script .= PHP_EOL . $this->_t(3) . "\$" . $this->bbb . "component" . $this->ddd . "_action_logs_extensions = new stdClass();";
		$script .= PHP_EOL . $this->_t(3) . "\$" . $this->bbb . "component" . $this->ddd . "_action_logs_extensions->extension = 'com_" . $this->bbb . "component" . $this->ddd . "';";

		$script .= PHP_EOL . PHP_EOL . $this->_t(3) . "//" . $this->setLine(__LINE__) . " Set the object into the action logs extensions table.";
		$script .= PHP_EOL . $this->_t(3) . "\$" . $this->bbb . "component" . $this->ddd . "_action_logs_extensions_Inserted = \$db->insertObject('#__action_logs_extensions', \$" . $this->bbb . "component" . $this->ddd . "_action_logs_extensions);";

		return str_replace(array_keys($placeholders), array_values($placeholders), $script);
	}

	/**
	 * get the View Post Install Script
	 * 
	 * @return  string
	 * 
	 */
	protected function getViewPOSTINSTALLSCRIPT(&$placeholders)
	{
		$script = PHP_EOL . PHP_EOL . $this->_t(3) . "//" . $this->setLine(__LINE__) . " Set db if not set already.";
		$script .= PHP_EOL . $this->_t(3) . "if (!isset(\$db))";
		$script .= PHP_EOL . $this->_t(3) . "{";
		$script .= PHP_EOL . $this->_t(4) . "\$db = JFactory::getDbo();";
		$script .= PHP_EOL . $this->_t(3) . "}";

		$script .= PHP_EOL . $this->_t(3) . "//" . $this->setLine(__LINE__) . " Create the " . $this->bbb . "view" . $this->ddd . " action log config object.";
		$script .= PHP_EOL . $this->_t(3) . "\$" . $this->bbb . "view" . $this->ddd . "_action_log_config = new stdClass();";
		$script .= PHP_EOL . $this->_t(3) . "\$" . $this->bbb . "view" . $this->ddd . "_action_log_config->type_title = '" . $this->bbb . "VIEW" . $this->ddd . "';";
		$script .= PHP_EOL . $this->_t(3) . "\$" . $this->bbb . "view" . $this->ddd . "_action_log_config->type_alias = 'com_" . $this->bbb . "component" . $this->ddd . "." . $this->bbb . "view" . $this->ddd . "';";
		$script .= PHP_EOL . $this->_t(3) . "\$" . $this->bbb . "view" . $this->ddd . "_action_log_config->id_holder = 'id';";
		$script .= PHP_EOL . $this->_t(3) . "\$" . $this->bbb . "view" . $this->ddd . "_action_log_config->title_holder = '<<<MAIN_TITLE>>>';";
		$script .= PHP_EOL . $this->_t(3) . "\$" . $this->bbb . "view" . $this->ddd . "_action_log_config->table_name = '#__" . $this->bbb . "component" . $this->ddd . "_" . $this->bbb . "view" . $this->ddd . "';";
		$script .= PHP_EOL . $this->_t(3) . "\$" . $this->bbb . "view" . $this->ddd . "_action_log_config->text_prefix = '" . $this->bbb . "LANG_PREFIX" . $this->ddd . "';";

		$script .= PHP_EOL . PHP_EOL . $this->_t(3) . "//" . $this->setLine(__LINE__) . " Set the object into the action log config table.";
		$script .= PHP_EOL . $this->_t(3) . "\$" . $this->bbb . "view" . $this->ddd . "_Inserted = \$db->insertObject('#__action_log_config', \$" . $this->bbb . "view" . $this->ddd . "_action_log_config);";

		return str_replace(array_keys($placeholders), array_values($placeholders), $script);
	}

	/**
	 * get the Main Post Update Script
	 * 
	 * @return  string
	 * 
	 */
	protected function getMainPOSTUPDATESCRIPT(&$placeholders)
	{
		$script = PHP_EOL . PHP_EOL . $this->_t(3) . "//" . $this->setLine(__LINE__) . " Set db if not set already.";
		$script .= PHP_EOL . $this->_t(3) . "if (!isset(\$db))";
		$script .= PHP_EOL . $this->_t(3) . "{";
		$script .= PHP_EOL . $this->_t(4) . "\$db = JFactory::getDbo();";
		$script .= PHP_EOL . $this->_t(3) . "}";

		$script .= PHP_EOL . $this->_t(3) . "//" . $this->setLine(__LINE__) . " Create the " . $this->bbb . "component" . $this->ddd . " action logs extensions object.";
		$script .= PHP_EOL . $this->_t(3) . "\$" . $this->bbb . "component" . $this->ddd . "_action_logs_extensions = new stdClass();";
		$script .= PHP_EOL . $this->_t(3) . "\$" . $this->bbb . "component" . $this->ddd . "_action_logs_extensions->extension = 'com_" . $this->bbb . "component" . $this->ddd . "';";

		$script .= PHP_EOL . PHP_EOL . $this->_t(3) . "//" . $this->setLine(__LINE__) . " Check if " . $this->bbb . "component" . $this->ddd . " action log extension is already in action logs extensions DB.";
		$script .= PHP_EOL . $this->_t(3) . "\$query = \$db->getQuery(true);";
		$script .= PHP_EOL . $this->_t(3) . "\$query->select(\$db->quoteName(array('id')));";
		$script .= PHP_EOL . $this->_t(3) . "\$query->from(\$db->quoteName('#__action_logs_extensions'));";
		$script .= PHP_EOL . $this->_t(3) . "\$query->where(\$db->quoteName('extension') . ' LIKE '. \$db->quote(\$" . $this->bbb . "component" . $this->ddd . "_action_logs_extensions->extension));";
		$script .= PHP_EOL . $this->_t(3) . "\$db->setQuery(\$query);";
		$script .= PHP_EOL . $this->_t(3) . "\$db->execute();";

		$script .= PHP_EOL . PHP_EOL . $this->_t(3) . "//" . $this->setLine(__LINE__) . " Set the object into the action logs extensions table if not found.";
		$script .= PHP_EOL . $this->_t(3) . "if (!\$db->getNumRows())";
		$script .= PHP_EOL . $this->_t(3) . "{";
		$script .= PHP_EOL . $this->_t(4) . "\$" . $this->bbb . "component" . $this->ddd . "_action_logs_extensions_Inserted = \$db->insertObject('#__action_logs_extensions', \$" . $this->bbb . "component" . $this->ddd . "_action_logs_extensions);";
		$script .= PHP_EOL . $this->_t(3) . "}";

		return str_replace(array_keys($placeholders), array_values($placeholders), $script);
	}

	/**
	 * get the View Post Update Script
	 * 
	 * @return  string
	 * 
	 */
	protected function getViewPOSTUPDATESCRIPT(&$placeholders)
	{
		$script = PHP_EOL . PHP_EOL . $this->_t(3) . "//" . $this->setLine(__LINE__) . " Set db if not set already.";
		$script .= PHP_EOL . $this->_t(3) . "if (!isset(\$db))";
		$script .= PHP_EOL . $this->_t(3) . "{";
		$script .= PHP_EOL . $this->_t(4) . "\$db = JFactory::getDbo();";
		$script .= PHP_EOL . $this->_t(3) . "}";

		$script .= PHP_EOL . $this->_t(3) . "//" . $this->setLine(__LINE__) . " Create the " . $this->bbb . "view" . $this->ddd . " action log config object.";
		$script .= PHP_EOL . $this->_t(3) . "\$" . $this->bbb . "view" . $this->ddd . "_action_log_config = new stdClass();";
		$script .= PHP_EOL . $this->_t(3) . "\$" . $this->bbb . "view" . $this->ddd . "_action_log_config->id = null;";
		$script .= PHP_EOL . $this->_t(3) . "\$" . $this->bbb . "view" . $this->ddd . "_action_log_config->type_title = '" . $this->bbb . "VIEW" . $this->ddd . "';";
		$script .= PHP_EOL . $this->_t(3) . "\$" . $this->bbb . "view" . $this->ddd . "_action_log_config->type_alias = 'com_" . $this->bbb . "component" . $this->ddd . "." . $this->bbb . "view" . $this->ddd . "';";
		$script .= PHP_EOL . $this->_t(3) . "\$" . $this->bbb . "view" . $this->ddd . "_action_log_config->id_holder = 'id';";
		$script .= PHP_EOL . $this->_t(3) . "\$" . $this->bbb . "view" . $this->ddd . "_action_log_config->title_holder = '<<<MAIN_TITLE>>>';";
		$script .= PHP_EOL . $this->_t(3) . "\$" . $this->bbb . "view" . $this->ddd . "_action_log_config->table_name = '#__" . $this->bbb . "component" . $this->ddd . "_" . $this->bbb . "view" . $this->ddd . "';";
		$script .= PHP_EOL . $this->_t(3) . "\$" . $this->bbb . "view" . $this->ddd . "_action_log_config->text_prefix = '" . $this->bbb . "LANG_PREFIX" . $this->ddd . "';";

		$script .= PHP_EOL . PHP_EOL .  $this->_t(3) . "//" . $this->setLine(__LINE__) . " Check if " . $this->bbb . "view" . $this->ddd . " action log config is already in action_log_config DB.";
		$script .= PHP_EOL . $this->_t(3) . "\$query = \$db->getQuery(true);";
		$script .= PHP_EOL . $this->_t(3) . "\$query->select(\$db->quoteName(array('id')));";
		$script .= PHP_EOL . $this->_t(3) . "\$query->from(\$db->quoteName('#__action_log_config'));";
		$script .= PHP_EOL . $this->_t(3) . "\$query->where(\$db->quoteName('type_alias') . ' LIKE '. \$db->quote(\$" . $this->bbb . "view" . $this->ddd . "_action_log_config->type_alias));";
		$script .= PHP_EOL . $this->_t(3) . "\$db->setQuery(\$query);";
		$script .= PHP_EOL . $this->_t(3) . "\$db->execute();";

		$script .= PHP_EOL . PHP_EOL . $this->_t(3) . "//" . $this->setLine(__LINE__) . " Set the object into the content types table.";
		$script .= PHP_EOL . $this->_t(3) . "if (\$db->getNumRows())";
		$script .= PHP_EOL . $this->_t(3) . "{";
		$script .= PHP_EOL . $this->_t(4) . "\$" . $this->bbb . "view" . $this->ddd . "_action_log_config->id = \$db->loadResult();";
		$script .= PHP_EOL . $this->_t(4) . "\$" . $this->bbb . "view" . $this->ddd . "_action_log_config_Updated = \$db->updateObject('#__action_log_config', \$" . $this->bbb . "view" . $this->ddd . "_action_log_config, 'id');";
		$script .= PHP_EOL . $this->_t(3) . "}";
		$script .= PHP_EOL . $this->_t(3) . "else";
		$script .= PHP_EOL . $this->_t(3) . "{";
		$script .= PHP_EOL . $this->_t(4) . "\$" . $this->bbb . "view" . $this->ddd . "_action_log_config_Inserted = \$db->insertObject('#__action_log_config', \$" . $this->bbb . "view" . $this->ddd . "_action_log_config);";
		$script .= PHP_EOL . $this->_t(3) . "}";

		return str_replace(array_keys($placeholders), array_values($placeholders), $script);
	}

	/**
	 * get the Main Uninstall Script
	 * 
	 * @return  string
	 * 
	 */
	protected function getMainUNINSTALLSCRIPT(&$placeholders)
	{
		$script = PHP_EOL . PHP_EOL . $this->_t(2) . "//" . $this->setLine(__LINE__) . " Set db if not set already.";
		$script .= PHP_EOL . $this->_t(2) . "if (!isset(\$db))";
		$script .= PHP_EOL . $this->_t(2) . "{";
		$script .= PHP_EOL . $this->_t(3) . "\$db = JFactory::getDbo();";
		$script .= PHP_EOL . $this->_t(2) . "}";
		$script .= PHP_EOL . $this->_t(2) . "//" . $this->setLine(__LINE__) . " Set app if not set already.";
		$script .= PHP_EOL . $this->_t(2) . "if (!isset(\$app))";
		$script .= PHP_EOL . $this->_t(2) . "{";
		$script .= PHP_EOL . $this->_t(3) . "\$app = JFactory::getApplication();";
		$script .= PHP_EOL . $this->_t(2) . "}";

		$script .= PHP_EOL . $this->_t(2) . "//" . $this->setLine(__LINE__) . " Remove " . $this->bbb . "Component" . $this->ddd . " from the action_logs_extensions table";
		$script .= PHP_EOL . $this->_t(2) . "\$" . $this->bbb . "component" . $this->ddd . "_action_logs_extensions = array( \$db->quoteName('extension') . ' = ' . \$db->quote('com_" . $this->bbb . "component" . $this->ddd . "') );";
		$script .= PHP_EOL . $this->_t(2) . "//" . $this->setLine(__LINE__) . " Create a new query object.";
		$script .= PHP_EOL . $this->_t(2) . "\$query = \$db->getQuery(true);";
		$script .= PHP_EOL . $this->_t(2) . "\$query->delete(\$db->quoteName('#__action_logs_extensions'));";
		$script .= PHP_EOL . $this->_t(2) . "\$query->where(\$" . $this->bbb . "component" . $this->ddd . "_action_logs_extensions);";
		$script .= PHP_EOL . $this->_t(2) . "\$db->setQuery(\$query);";

		$script .= PHP_EOL . $this->_t(2) . "//" . $this->setLine(__LINE__) . " Execute the query to remove " . $this->bbb . "Component" . $this->ddd . "";
		$script .= PHP_EOL . $this->_t(2) . "\$" . $this->bbb . "component" . $this->ddd . "_removed_done = \$db->execute();";
		$script .= PHP_EOL . $this->_t(2) . "if (\$" . $this->bbb . "component" . $this->ddd . "_removed_done)";
		$script .= PHP_EOL . $this->_t(2) . "{";
		$script .= PHP_EOL . $this->_t(3) . "//" . $this->setLine(__LINE__) . " If successfully remove " . $this->bbb . "Component" . $this->ddd . " add queued success message.";
		$script .= PHP_EOL . $this->_t(3) . "\$app->enqueueMessage(JTe" . "xt::_('The com_" . $this->bbb . "component" . $this->ddd . " extension was removed from the <b>#__action_logs_extensions</b> table'));";
		$script .= PHP_EOL . $this->_t(2) . "}";

		return str_replace(array_keys($placeholders), array_values($placeholders), $script);
	}

	/**
	 * get the View Uninstall Script
	 * 
	 * @return  string
	 * 
	 */
	protected function getViewUNINSTALLSCRIPT(&$placeholders)
	{
		$script = PHP_EOL . PHP_EOL . $this->_t(2) . "//" . $this->setLine(__LINE__) . " Set db if not set already.";
		$script .= PHP_EOL . $this->_t(2) . "if (!isset(\$db))";
		$script .= PHP_EOL . $this->_t(2) . "{";
		$script .= PHP_EOL . $this->_t(3) . "\$db = JFactory::getDbo();";
		$script .= PHP_EOL . $this->_t(2) . "}";
		$script .= PHP_EOL . $this->_t(2) . "//" . $this->setLine(__LINE__) . " Set app if not set already.";
		$script .= PHP_EOL . $this->_t(2) . "if (!isset(\$app))";
		$script .= PHP_EOL . $this->_t(2) . "{";
		$script .= PHP_EOL . $this->_t(3) . "\$app = JFactory::getApplication();";
		$script .= PHP_EOL . $this->_t(2) . "}";

		$script .= PHP_EOL . $this->_t(2) . "//" . $this->setLine(__LINE__) . " Remove " . $this->bbb . "Component" . $this->ddd . " " . $this->bbb . "View" . $this->ddd . " from the action_log_config table";
		$script .= PHP_EOL . $this->_t(2) . "\$" . $this->bbb . "view" . $this->ddd . "_action_log_config = array( \$db->quoteName('type_alias') . ' = '. \$db->quote('com_" . $this->bbb . "component" . $this->ddd . "." . $this->bbb . "view" . $this->ddd . "') );";
		$script .= PHP_EOL . $this->_t(2) . "//" . $this->setLine(__LINE__) . " Create a new query object.";
		$script .= PHP_EOL . $this->_t(2) . "\$query = \$db->getQuery(true);";
		$script .= PHP_EOL . $this->_t(2) . "\$query->delete(\$db->quoteName('#__action_log_config'));";
		$script .= PHP_EOL . $this->_t(2) . "\$query->where(\$" . $this->bbb . "view" . $this->ddd . "_action_log_config);";
		$script .= PHP_EOL . $this->_t(2) . "\$db->setQuery(\$query);";
		$script .= PHP_EOL . $this->_t(2) . "//" . $this->setLine(__LINE__) . " Execute the query to remove com_" . $this->bbb . "component" . $this->ddd . "." . $this->bbb . "view" . $this->ddd . "";
		$script .= PHP_EOL . $this->_t(2) . "\$" . $this->bbb . "view" . $this->ddd . "_action_log_config_done = \$db->execute();";
		$script .= PHP_EOL . $this->_t(2) . "if (\$" . $this->bbb . "view" . $this->ddd . "_action_log_config_done)";
		$script .= PHP_EOL . $this->_t(2) . "{";
		$script .= PHP_EOL . $this->_t(3) . "//" . $this->setLine(__LINE__) . " If successfully removed " . $this->bbb . "Component" . $this->ddd . " " . $this->bbb . "View" . $this->ddd . " add queued success message.";
		$script .= PHP_EOL . $this->_t(3) . "\$app->enqueueMessage(JTe" . "xt::_('The com_" . $this->bbb . "component" . $this->ddd . "." . $this->bbb . "view" . $this->ddd . " type alias was removed from the <b>#__action_log_config</b> table'));";
		$script .= PHP_EOL . $this->_t(2) . "}";

		return str_replace(array_keys($placeholders), array_values($placeholders), $script);
	}

	/**
	 * Set the line number in comments
	 * 
	 * @param   int   $nr  The line number
	 * 
	 * @return  void
	 * 
	 */
	protected function setLine($nr)
	{
		if ($this->debugLinenr)
		{
			return ' [Plugin-ActionLog-Compiler ' . $nr . ']';
		}
		return '';
	}

	/**
	 * Set the tab/space
	 * 
	 * @param   int   $nr  The number of tag/space
	 * 
	 * @return  string
	 * 
	 */
	protected function _t($nr)
	{
		// use global method for conformity
		return ComponentbuilderHelper::_t($nr);
	}

	/**
	 * The array of active components
	 * 
	 * @var     array
	 */
	protected $componentsActive;

	/**
	 * The activate option
	 * 
	 * @var     int
	 */
	protected $activateOption = 0;

	/**
	 * Set the line number in comments
	 * 
	 * @param   string  $context  The context of the current executing component
	 * 
	 * @return  bool
	 * 
	 */
	protected function componentActive(&$context)
	{
		// check the active option
		if (!$this->activateOption)
		{
			$this->activateOption = $this->params->get('activate_option', 1);
		}
		// active for all components
		if ($this->activateOption == 1)
		{
			return true;
		}
		// first check is we have the active components set
		if ($this->activateOption == 2 && !ComponentbuilderHelper::checkArray($this->componentsActive))
		{
			$this->componentsActive = $this->params->get('components');
		}
		// only check if there are active
		if (ComponentbuilderHelper::checkArray($this->componentsActive))
		{
			return in_array((int) filter_var($context, FILTER_SANITIZE_NUMBER_INT), $this->componentsActive);
		}
		return false;
	}

}
